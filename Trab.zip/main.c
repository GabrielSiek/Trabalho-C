#include <stdio.h>
#include "hardware_library.h"

int main(){
	
	W(0,10,0b110,3);
	printf("%d\n", R(1,8,8));
	printf("%d\n", R(0,10,1));
	printf("%d\n", R(0,0,16));
	char c[24] = "Lebron James Pai";
	changeString(c);

	return 0;
}